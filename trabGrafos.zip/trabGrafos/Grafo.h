#include "No.h"
#include <set>
#include <vector>

using namespace std;

class Grafo
{
    private:
     int n;
     int e;
     No* ListaNo;
     int nAresta;
     int grau;
     bool direcionado;
     bool pondNo;
     bool pondAresta;
     vector < int > auxCaminhamentoLargura(No* p, set < int > &visitados);
     void auxCaminhamentoProf(No* p, set < int > &visitados);
     bool ehConexo(set < int > visitados);
     int ehFortementeConexo(No* p, set < int > &ida);
     void auxOT(No* primeiro, std::vector< int > &vect, No** visitados, int n);
     No* buscaNo(int id);
     vector < int > ordenaGrau();
     int auxOrdenaGrau(set < int > &visitados);
     vector < int > gulosoIndependente(float alfa);
     void auxGuloso_atualizaCandidatos(vector < int > &candidatos, int remocao);
     bool temAresta(int id1, int id2);

    public:
     //Grafo();
     Grafo(bool dir);
     ~Grafo();
     bool busca(int id);
     //Apenas declaracao do metodo
     void conectar(int id1, int id2);
     void desconectar(int id1, int id2);
     void caminhamentoLargura();
     void printGrafo();
     void caminhamentoProf();
     void excluirNo(int id); ///EM ANDAMENTO
     int contaNos();
     int componentesConexas();
     void inserir(int id1);
     int componentesFortementeConexas();
     void ordenacoesTopologicas();
     void subconjuntoIndependenteMax();
};
