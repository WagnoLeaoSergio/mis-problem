#include "Grafo.h"
#include <stdio.h>
#include <iostream>
#include <queue>
#include <set>
#include <stack>
#include <stdlib.h>
#include <list>
#include <stdlib.h>
#include <algorithm>
#include <time.h>

using namespace std;
/*
Grafo::Grafo()
{
    cout << "\nA graph has been created\n";

    ListaNo = NULL;
    nAresta = 0;
    grau = 0;
    direcionado = false;
    pondNo = false;
    pondAresta = false;
}
*/
Grafo::Grafo(bool dir)
{
    cout << "A graph has been created\n";
    ListaNo = NULL;
    nAresta = 0;
    grau = 0;
    n = 0;
    e = 0;
    direcionado = dir;
    pondNo = false;
    pondAresta = false;
}

Grafo::~Grafo()
{
    for(No* t = ListaNo; t != NULL;)
    {
        for(Aresta* p = t->getAdj(); p != NULL;)
        {
            Aresta* aux1 = p->getProx();
            delete p;
            p = aux1;
        }

        No* aux2 = t->getProx();
        delete t;
        t = aux2;
    }
    cout << "\nA graph has been destroyed\n";
}

bool Grafo::busca(int id)
{
    for(No* p = ListaNo; p != NULL; p = p->getProx())
    {
        if(p->getId() == id)
            return true;
    }
    return false;
}

void Grafo::inserir(int id)
{
    if(!(busca(id)))
    {
        No *p = new No;
        p->setId(id);
        p->setEntrada(0);
        p->setSaida(0);
        if(ListaNo != NULL)
        {
            for(No *i = ListaNo; i != NULL; i = i->getProx())
                if(i->getProx() == NULL)
                {
                    //cout << i->getId() << "asd" << endl;
                    i->setProx(p);
                    p->setProx(NULL);
                    p->setAnt(i);
                    break;
                }
        }
        else
        {
            ListaNo = p;
            ListaNo->setProx(NULL);
            ListaNo->setAnt(NULL);
        }
        n++;
    }
    else
        return;
}

void Grafo::conectar(int id1, int id2)
{
    if(direcionado)
    {
        if(!busca(id1) || !busca(id2))
        {
            cout << "Erro: conexao invalida." << endl;
            //exit(3);
        }
        else
        {
            for(No *n = ListaNo; n != NULL; n = n->getProx())
            {
                if(n->getId() == id1)
                {
                    n->alocarAdj(id2);
                    n->setSaida(n->getSaida() + 1);
                }
                if(n->getId() == id2)
                {
                    n->setEntrada(n->getEntrada() + 1);
                }
            }
            e++;
        }
    }
    else
    {
        if(!busca(id1) || !busca(id2))
        {
            cout << "Erro: conexao invalida." << id1 << id2 << endl;
            //exit(3);
        }
        else
        {
            for(No *n = ListaNo; n != NULL; n = n->getProx())
            {
                if(n->getId() == id1)
                {
                    n->alocarAdj(id2);
                    n->setEntrada(n->getEntrada() + 1);
                }
                if(n->getId() == id2)
                {
                    n->alocarAdj(id1);
                    n->setEntrada(n->getEntrada() + 1);
                }
            }
            e++;
        }
    }
}

///EM ANDAMENTO---------------------------------------------------
void Grafo::desconectar(int id1, int id2)
{
    if(!(busca(id1)))
        exit(1);
        //return;
    if(!(busca(id2)))
        exit(2);
        //return;
    for(No *n = ListaNo; n != NULL; n = n->getProx())
    {
        if(n->getId() == id1)
        {
            //for(Aresta* a = n->getAdj())
        }
        if(n->getId() == id2)
            n->alocarAdj(id1);
    }
}
///----------------------------------------------------------------
void Grafo::caminhamentoLargura()
{
    set < int > visitados;
    No* primeiro = ListaNo;
    auxCaminhamentoLargura(primeiro, visitados);
}

vector < int > Grafo::auxCaminhamentoLargura(No* p, set < int > &visitados)
{
    queue < int > fila;
    int vertice = p->getId();
    fila.push(vertice);
    visitados.insert(p->getId());

    vector < int > componente;
    componente.push_back(vertice);
    cout << vertice << endl;

    while(!fila.empty())
    //while(fila.size() > 0)
    {
        //cout << "teste" << endl;
        vertice = fila.front();
        fila.pop();
        //cout << "tam " << fila.size() << endl;
        No* i;
        for(i = ListaNo; i != NULL; i = i->getProx())
        {
            if(i->getId() == vertice)
                break;
        }
        for(Aresta *a = i->getAdj(); a != NULL; a = a->getProx())
        {
            if(visitados.find(a->getNoadj()) == visitados.end())
            {
                fila.push(a->getNoadj());
                visitados.insert(a->getNoadj());
                componente.push_back(a->getNoadj());
                cout << a->getNoadj() << endl;
            }
        }
        //cout << "asdasdas" << fila.size() << endl;
    }
    return componente;
}

void Grafo::caminhamentoProf()
{
    set < int > visitados;
    No* p = ListaNo;
    auxCaminhamentoProf(p, visitados);
}

void Grafo::auxCaminhamentoProf(No* p, set < int > &visitados)
{
    stack < int > pilha;
    int vertice = p->getId();
    pilha.push(vertice);
    visitados.insert(p->getId());

    //cout << vertice << endl;

    while(!pilha.empty())
    {
        vertice = pilha.top();
        cout << vertice << endl;
        pilha.pop();
        No* i;
        for(i = p; i != NULL; i = i->getProx())
        {
            if(i->getId() == vertice)
                break;
        }
        for(Aresta *a = i->getAdj(); a != NULL; a = a->getProx())
        {
            if(visitados.find(a->getNoadj()) == visitados.end())
            {
                pilha.push(a->getNoadj());
                visitados.insert(a->getNoadj());
                //cout << a->getNoadj() << endl;
            }
        }
    }
}

void Grafo::printGrafo()
{
    for(No* p = ListaNo; p != NULL; p = p->getProx())
    {
        cout << p->getId() << " -> ";
        if(p->getAdj() != NULL)
            for(Aresta* a = p->getAdj(); a != NULL; a = a->getProx())
                cout << a->getNoadj() << " ";
        cout << endl;
    }
}

int Grafo::contaNos()
{
    int cont = 0;
    for(No* p = ListaNo; p != NULL; p = p->getProx())
    {
        cont++;
    }
    //cout << "numero de nos: " << cont << endl;
    return cont;
}

bool Grafo::ehConexo(set < int > visitados)
{
    if((int) visitados.size() == contaNos())
        return true;
    else
        return false;
}

int Grafo::componentesConexas()
{
    vector < int > c;
    int cont = 0;
    set < int > visitados;
    No* p = ListaNo;
    set < set < int > > componentes;
    if(ehConexo(visitados))
    {
        cout << "Componente " << cont << " " << endl;
        c = auxCaminhamentoLargura(p, visitados);
        cont++;
        return cont;
    }
    else
    {
        vector < vector < int > > componentes;
        //cont++;
        for(No* p = ListaNo; p != NULL; p = p->getProx())
        {
            if(visitados.find(p->getId()) == visitados.end())
            {
                set < int > comp;
                cont++;
                cout << "Componente " << cont - 1 << " " << endl;
                componentes.push_back(auxCaminhamentoLargura(p, visitados));
                if(ehConexo(visitados))
                {
                    break;
                }
            }
        }
        cout << "deadjdleahdlakda " << componentes[0][0];
        /* HOW TO USE ITERATOR
        set < No* > componente;
        componente.insert(ListaNo);
        set < No* > ::iterator it;
        it = componente.begin();
        cout << "teste iterator de p, id: " << (*it)->getId();
        */
        return cont;
    }
}

int Grafo::ehFortementeConexo(No* p, set < int > &visitados)
{
/*
    set < int > volta;
    cout << "before 2arv tam " << ida.size() << endl;
    if((int) ida.size() == contaNos())
    {
        cout << "erro no tam" << endl;
        cout << "arv tam " << ida.size() << endl;
        cout << "int total " << contaNos() << endl;
        //while(!ida.empty())
        //{
            //int i = ida.begin();
            //No* t;
            for(No* t = p->getProx(); t != NULL; t = t->getProx())
            {
                if(ida.find(t->getId()) != ida.end())
                {
                    //set < int > volta;
                    cout << "xd" << volta.size() << endl;
                    auxCaminhamentoProf(t, volta);
                    cout << "xd" << endl;
                    if(volta.find(p->getId()) == volta.end())
                        return false;
                    //volta.clear();
                    //break;
                }
                //if(t->getId() == i)
                    //break;
            }
            cout << "xd" << endl;
            return true;
            //set < int > volta;
            //auxCaminhamentoLargura(t, volta);

            //for(; t != NULL; t = t->getProx())
            {
                if(volta.find(p->getId()) == volta.end())
                {
                    //cont++;
                    //auxCaminhamentoLargura(p, visitados);
                    return false;
                }
                else
                {
                    ida.erase(t->getId());
                    volta.clear();
                }
            }
        }
        return true;-
    }
    else
        return false;*/
    /*ULTIMA TENTATIVA
    for(No* i = p->getProx(); i != NULL; i = i->getProx())
    {
        if(visitados.find(i->getId()) != visitados.end())
        {
            set < int > visitados2;
            auxCaminhamentoLargura(i, visitados2);
            if(visitados2.size() != visitados.size())
            {
                visitados.erase(i->getId());
            }
            //visitados2.clear();
        }
    }
    if(visitados.size() == 0)
        return true;
    else
        return false;
    //fim1
    if((int) visitados.size() == contaNos())
        return true;
    else
        return false;*/
    int cont = 0;
    set < int > comp;
    queue < int > fila;
    int vertice = p->getId();
    fila.push(vertice);
    visitados.insert(p->getId());

    vector < int > componente;
    componente.push_back(vertice);
    cout << vertice << endl;

    comp.insert(vertice);
    while(!fila.empty())
    //while(fila.size() > 0)
    {
        //cout << "teste" << endl;
        vertice = fila.front();
        fila.pop();
        //cout << "tam " << fila.size() << endl;
        No* i;
        for(i = ListaNo; i != NULL; i = i->getProx())
        {
            if(i->getId() == vertice)
                break;
        }
        for(Aresta *a = i->getAdj(); a != NULL; a = a->getProx())
        {
            set < int > visitados2;
            if(visitados.find(a->getNoadj()) == visitados.end())
            {
                No* j;
                for(j = ListaNo; j != NULL; j = j->getProx())
                {
                    if(j->getId() == a->getNoadj())
                        break;
                }
                cout << "adj: " << j->getId() << endl;
                auxCaminhamentoLargura(j, visitados2);
                set < int > ::iterator it;
                it = visitados2.begin();
                for(Aresta* t = j->getAdj(); t != NULL; t = t->getProx())
                {
                    cout << "it: " << *it << endl;
                    if(comp.find(t->getNoadj()) != comp.end())
                    {
                        comp.insert(*it);
                        comp.insert(j->getId());
                        cont++;
                        cout << "cont: " << cont << endl;
                        cout << "caminho: " << j->getId() << endl;
                        cout << "tam: " << comp.size() << endl;
                        break;
                    }
                }
                fila.push(a->getNoadj());
                visitados.insert(a->getNoadj());
                componente.push_back(a->getNoadj());
                cout << a->getNoadj() << endl;
            }
        }
        //cout << "asdasdas" << fila.size() << endl;
    }
    return cont;
}

int Grafo::componentesFortementeConexas()
{
/*
    int cont = 0;
    No* p = ListaNo;
    //cout << "p " << p->getId() << endl;
    set < int > ida;
    //cout << "before arv tam " << ida.size() << endl;
    auxCaminhamentoLargura(p, ida);
    //cout << "after arv tam " << ida.size() << endl;
    if(ehFortementeConexo(p, ida))
    {
        cout << "g f c" << endl;
        cont++;
        return cont;
    }
    else
    {
        //cont++;
        for(No* t = ListaNo->getProx(); t != NULL; t = t->getProx())
        {
            //if(ida.find(t->getId()) == ida.end())
            //{
                //cont++;
                //set < int > ida2;
                auxCaminhamentoLargura(p, ida);
                if(ehFortementeConexo(p, ida))
                {
                    cont++;
                    break;
                }
                //ida2.clear();
            //}
        }
        return cont;*/
        ///teste
        /*
        set < int > comp;
        No* p = ListaNo;
        //comp.insert(p->getId());
        int cont = 0;
        //set < int > visitados;
        //for(No* p = ListaNo; p != NULL; p = p->getProx())
        //{
            if(comp.find(p->getId()) == comp.end()){
            set < int > visitados;
            auxCaminhamentoLargura(p, visitados);
            for(No* t = ListaNo; t != NULL; t = t->getProx())
            {
                if(comp.find(p->getId()) == comp.end()){
                if(visitados.find(t->getId()) != visitados.end() && t != p)
                {
                    cout << "esse " << t->getId() << endl;
                    cout << "veio desse " << p->getId() << endl;
                    set < int > visitados2;
                    auxCaminhamentoLargura(t, visitados2);
                    if(!visitados2.empty())
                        if(visitados2.find(p->getId()) != visitados2.end())
                        {
                            cont++;
                            //auxCaminhamentoLargura(t, comp);
                            comp.insert(t->getId());
                            cout << "INSERCAO NA ARVORE" << t->getId() << endl;
                            break;
                        }
                    cout << "cont ta assim " << cont << endl;
                }

            }}
            //if(aux == (int) visitados.size())
                    //cont++;
            }*/
        //}
        //return cont;
        No* p = ListaNo;
        set < int > v;
        int cont = 0;
        for(; v.find(p->getId()) == v.end() && p != NULL; p = p->getProx())
        {
            cont += ehFortementeConexo(p, v);
        }
        return cont;
    }
    /*
    int cont = 0;
    set < int > visitados;
    No* p = ListaNo;
    auxCaminhamentoLargura(p, visitados);
    if(ehConexo(visitados))
    {
        cont++;
        return cont;
    }
    else
    {
        cont++;
        for(No* p = ListaNo; p != NULL; p = p->getProx())
        {
            if(visitados.find(p->getId()) == visitados.end())
            {
                cont++;
                auxCaminhamentoLargura(p, visitados);
                if(ehConexo(visitados))
                {
                    break;
                }
            }
        }
        return cont;
    }
    int cont = 0;
    //No* p = ListaNo;
    for(No* p = ListaNo; p != NULL; p = p->getProx())
    {
        set < int > visitados;
        auxCaminhamentoLargura(p, visitados);
        if(ehFortementeConexo(p, visitados))
        {
            cont++;
            return cont;
        }
    }*/
//}

/*
void Grafo::ordenacaoTopologica()
{
    set < int > visitados;
    int cont = 0;
    while(cont < contaNos())
    {
        No* p = ListaNo;
        No* menor = p;
        for(; p != NULL; p = p->getProx())
        {
            if(visitados.find(p->getId()) == visitados.end())
                if(p->getEntrada() < menor->getEntrada())
                {
                    menor = p;
                    visitados.insert(menor->getId());
                }
        }
        cont++;
        cout << menor->getId() << " ";
        menor = p->getProx();
    }
    cout << endl;

}*/


///EM ANDAMENTO------------------
/*
void Grafo::excluirNo(int id)
{
    //No* p = ListaNo;
    ListaNo->desalocarAdj(id);
}
*/
///------------------------------


No* Grafo::buscaNo(int id)
{
    for(No* p = ListaNo; p != NULL; p = p->getProx())
    {
        if(p->getId() == id)
            return p;
    }
    return NULL;
}

void Grafo::auxOT(No* primeiro, std::vector< int > &vect, No** visitados, int n)
{
   No* p = primeiro;
   int j = 0;

    for(int i = 0; i < n; i++)
    {
        visitados[i] = NULL;
    }

    queue<No*> fila;
    fila.push(p);
    visitados[0] = p;

    j++;

        while(!(fila.empty()))
        {
            No* q = fila.front();
            fila.pop();

            vect.push_back(q->getId());

            Aresta* a = q->getAdj();


            for(; a != NULL; a = a->getProx())
            {

                bool jaFoi = false;
                No* aux = this->buscaNo(a->getNoadj());

                for(int i = 0; i < n; i++)
                {
                    if(visitados[i] == aux)
                    {
                        jaFoi = true;
                    }
                }

                if(!jaFoi)
                {
                    fila.push(aux);
                    visitados[j] = aux;
                    j++;
                }
                if(j == n)
                    break;
            }

        }
}

void Grafo::ordenacoesTopologicas()
{
    if(e > n - 1 || !direcionado)
    {
        cout << "\nGrafo possui pelo menos um ciclo, Ordenacao Topologica impossivel" << endl;
        //exit(0);
        return;
    }

    No* p = ListaNo;
    vector<No*> nos;
    vector<int> ot;
    queue<No*>fontes;

    No** visitados = new No*[n]();

    for(; p != NULL; p = p->getProx())
    {
        nos.push_back(p);
        if(p->getEntrada() == 0)
            fontes.push(p);
    }


    while(!fontes.empty())
    {
        No* r = fontes.front();
        auxOT(r, ot, visitados, n);
        fontes.pop();
    }

    cout << "\nOrdenacao topologica: ";
    for (int i = 0; i < (int)ot.size(); i++)
    {
        cout << ot[i] << ", ";
    }
}

int Grafo::auxOrdenaGrau(set < int > &visitados)
{
    if(ListaNo != NULL)
    {
        int menorGrau = ListaNo->getEntrada();
        cout << "menor grau: " << menorGrau << endl;
        No* p = ListaNo;
        No* t = p;
        for(No* i = ListaNo; i != NULL; i++)
        {
            if(visitados.find(i->getId()) == visitados.end())
            {
                menorGrau = i->getEntrada();
                t = i;
                break;
            }
        }
        //No* p = ListaNo;
        for(; p != NULL; p = p->getProx()){
            cout << "no atual: " << p->getId() << endl;
            if(p->getEntrada() <= menorGrau && visitados.find(p->getId()) == visitados.end()){
                menorGrau = p->getEntrada();
                t = p;
                cout << "menor grau: " << menorGrau << endl;
            }
        }
        cout << "no a ser inserido: " << t->getId() << "grau t: " << t->getEntrada() << endl;
        //cout << "no p: " << p->getId() << "grau p: " << p->getEntrada() << endl;
        visitados.insert(t->getId());
        return t->getId();
    }
    return -1;
}
vector < int > Grafo::ordenaGrau()
{
    vector < int > ordenados;
    set < int > visitados;
    for(int i = 0; i < n; i++)
    {
        cout << "asdasda" << endl;
        ordenados.push_back(auxOrdenaGrau(visitados));
    }
    return ordenados;
}

bool Grafo::temAresta(int id1, int id2)
{
    cout << "teste" << endl;
    for(No* p = ListaNo; p != NULL; p = p->getProx())
    {
        if(p->getId() == id1)
            for(Aresta* a = p->getAdj(); a != NULL; a = a->getProx())
                if(a->getNoadj() == id2)
                    return true;
        else
            if(p->getId() == id2)
                for(Aresta* a = p->getAdj(); a != NULL; a = a->getProx())
                    if(a->getNoadj() == id1)
                        return true;
    }
    return false;
}

void Grafo::auxGuloso_atualizaCandidatos(std::vector < int > &candidatos, int remocao)
{

    //set<int> excluidos;

    //for(int i = 0; i < (int)candidatos.size(); i++)
    for(int i = 0; i < (int)candidatos.size(); i++)
    {
        //vector<int>::iterator it;
        //it = candidatos.begin();
        if(remocao != candidatos[i])// && excluidos.find(candidatos[i]) == excluidos.end())
            cout << "aresta desse " << remocao << " com esse " << candidatos[i] << endl;
            cout << "bool: " << temAresta(remocao, candidatos[i]) << endl;
            if(temAresta(remocao, candidatos[i]))
            {
                cout << "bool sim" << endl;
                //cout << "apagou1 " << candidatos[i] << endl;

                //excluidos.insert(candidatos[i]);

                candidatos.erase(candidatos.begin() + i);
                //cout << "apagou " << candidatos[i] << endl;
            }
        //it++;
    }
    cout << "aresta ok" <<endl;
    for(int i = 0; i < (int)candidatos.size(); i++)
    {
        //vector<int>::iterator it;
        //it = candidatos.begin();
        if(candidatos[i] == remocao)
        {

            //excluidos.insert(candidatos[i]);

            candidatos.erase(candidatos.begin() + i);
            cout << "XD" << endl;
        }
        //it++;
    }
}

vector < int > Grafo::gulosoIndependente(float alfa)
{
    std::vector < int > candidatos = ordenaGrau();
    cout << "test" << endl;
    vector < int > solucao;
    //int i = rand() % (int)(candidatos.size() * alfa);
    //i = 0;
    int i;
    while(!candidatos.empty())
    {
        srand(time(NULL));/*
        if(candidatos.size() == 1)
            i = 0;*/
        srand(time(NULL));
        i = rand() % ((int)(candidatos.size() * alfa) + 1);
        cout << "                                  TAMANHO: " << candidatos.size() << " O i DEU: "  << i << endl;
        i = 0;
        solucao.push_back(candidatos[i]);
        auxGuloso_atualizaCandidatos(candidatos, candidatos[i]);
    }
    return solucao;
}

void Grafo::subconjuntoIndependenteMax()
{
    vector < int > sol = gulosoIndependente(0.9);
    for(int i = 0; i < (int)sol.size(); i++)
        cout << sol[i] << " " << endl;
}



