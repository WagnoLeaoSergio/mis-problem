#include <iostream>
#include "Grafo.h"

using namespace std;

int main()
{
    Grafo t(0);
    t.conectar(2, 5);
    t.conectar(2, 3);
    t.conectar(5, 4);
    t.conectar(3, 7);
    t.conectar(3, 8);
    t.conectar(10, 11);
    t.excluirNo(2);
    cout << "Caminhamento em largura: " << endl;
    t.caminhamentoLargura();
    cout << "Caminhamento em profundidade: " << endl;
    t.caminhamentoProf();
    cout << "Impressao do grafo:" << endl;
    t.printGrafo();
    return 0;
}
