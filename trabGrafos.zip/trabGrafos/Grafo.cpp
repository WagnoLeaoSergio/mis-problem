#include "Grafo.h"
#include <stdio.h>
#include <iostream>
#include <queue>
#include <set>
#include <stack>
#include <stdlib.h>

using namespace std;
/*
Grafo::Grafo()
{
    cout << "\nA graph has been created\n";

    ListaNo = NULL;
    nAresta = 0;
    grau = 0;
    direcionado = false;
    pondNo = false;
    pondAresta = false;
}
*/
Grafo::Grafo(bool dir)
{
    cout << "A graph has been created\n";
    ListaNo = NULL;
    nAresta = 0;
    grau = 0;
    direcionado = dir;
    pondNo = false;
    pondAresta = false;
}

Grafo::~Grafo()
{
    for(No* t = ListaNo; t != NULL;)
    {
        for(Aresta* p = t->getAdj(); p != NULL;)
        {
            Aresta* aux1 = p->getProx();
            delete p;
            p = aux1;
        }

        No* aux2 = t->getProx();
        delete t;
        t = aux2;
    }
    cout << "\nA graph has been destroyed\n";
}

bool Grafo::busca(int id)
{
    for(No* p = ListaNo; p != NULL; p = p->getProx())
    {
        if(p->getId() == id)
            return true;
    }
    return false;
}

void Grafo::conectar(int id1, int id2)
{
    if(!(busca(id1)))
    {
        No *p = new No;
        p->setId(id1);
        if(ListaNo != NULL)
        {
            for(No *i = ListaNo; i != NULL; i = i->getProx())
                if(i->getProx() == NULL)
                {
                    i->setProx(p);
                    break;
                }
        }
        else
            ListaNo = p;
    }
    if(!(busca(id2)))
    {
        No *t = new No;
        t->setId(id2);
        if(ListaNo != NULL)
        {
            for(No *j = ListaNo; j != NULL; j = j->getProx())
                if(j->getProx() == NULL)
                {
                    j->setProx(t);
                    break;
                }
        }
        else
            ListaNo = t;
    }

    for(No *n = ListaNo; n != NULL; n = n->getProx())
    {
        if(n->getId() == id1)
            n->alocarAdj(id2);
        if(n->getId() == id2)
            n->alocarAdj(id1);
    }
}

void Grafo::desconectar(int id1, int id2)
{
    if(!(busca(id1)))
        exit(1);
        //return;
    if(!(busca(id2)))
        exit(2);
        //return;
    for(No *n = ListaNo; n != NULL; n = n->getProx())
    {
        if(n->getId() == id1)
        {
            //for(Aresta* a = n->getAdj())
        }
        if(n->getId() == id2)
            n->alocarAdj(id1);
    }
}

void Grafo::caminhamentoLargura()
{
    set < int > visitados;
    No* primeiro = ListaNo;
    auxCaminhamentoLargura(primeiro, visitados);
}

void Grafo::auxCaminhamentoLargura(No* p, set < int > &visitados)
{
    queue < int > fila;
    int vertice = p->getId();
    fila.push(vertice);
    visitados.insert(p->getId());

    cout << vertice << endl;

    while(!fila.empty())
    {
        vertice = fila.front();
        fila.pop();
        No* i;
        for(i = p; i != NULL; i = i->getProx())
        {
            if(i->getId() == vertice)
                break;
        }
        for(Aresta *a = i->getAdj(); a != NULL; a = a->getProx())
        {
            if(visitados.find(a->getNoadj()) == visitados.end())
            {
                fila.push(a->getNoadj());
                visitados.insert(a->getNoadj());
                cout << a->getNoadj() << endl;
            }
        }
    }
}

void Grafo::caminhamentoProf()
{
    set < int > visitados;
    No* p = ListaNo;
    auxCaminhamentoProf(p, visitados);
}

void Grafo::auxCaminhamentoProf(No* p, set < int > &visitados)
{
    stack < int > pilha;
    int vertice = p->getId();
    pilha.push(vertice);
    visitados.insert(p->getId());

    //cout << vertice << endl;

    while(!pilha.empty())
    {
        vertice = pilha.top();
        cout << vertice << endl;
        pilha.pop();
        No* i;
        for(i = p; i != NULL; i = i->getProx())
        {
            if(i->getId() == vertice)
                break;
        }
        for(Aresta *a = i->getAdj(); a != NULL; a = a->getProx())
        {
            if(visitados.find(a->getNoadj()) == visitados.end())
            {
                pilha.push(a->getNoadj());
                visitados.insert(a->getNoadj());
                //cout << a->getNoadj() << endl;
            }
        }
    }
}

void Grafo::printGrafo()
{
    for(No* p = ListaNo; p != NULL; p = p->getProx())
    {
        cout << p->getId() << " -> ";
        for(Aresta* a = p->getAdj(); a != NULL; a = a->getProx())
            cout << a->getNoadj() << " ";
        cout << endl;
    }
}

void Grafo::excluirNo(int id)
{
    //No* p = ListaNo;
    ListaNo->desalocarAdj(id);
}
