#include "No.h"
#include <set>

using namespace std;

class Grafo
{
    private:
     No* ListaNo;
     int nAresta;
     int grau;
     bool direcionado;
     bool pondNo;
     bool pondAresta;
     void auxCaminhamentoLargura(No* p, set < int > &visitados);
     void auxCaminhamentoProf(No* p, set < int > &visitados);

    public:
     //Grafo();
     Grafo(bool dir);
     ~Grafo();
     bool busca(int id);
     //Apenas declaracao do metodo
     void conectar(int id1, int id2);
     void desconectar(int id1, int id2);
     void caminhamentoLargura();
     void printGrafo();
     void caminhamentoProf();
     void excluirNo(int id);
};
