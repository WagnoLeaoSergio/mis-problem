
public class Exames
{
    private int triglicerides;
    private int colesterolTotal;
    private int colesterolHDL;
    private int colesterolLDL;
    private int colesterolVLDL;
    private int glicose;
    
    public void setTriglicerides(int triglicerides){
        this.triglicerides = triglicerides;
    }
    public int getTriglicerides(){
        return this.triglicerides;
    }
    
    public void setColesterolTotal(int colesterolTotal){
        this.colesterolTotal = colesterolTotal;
    }
    public int getColesterolTotal(){
        return this.colesterolTotal;
    }
    
    public void setColesterolHDL(int colesterolHDL){
        this.colesterolHDL = colesterolHDL;
    }
    public int getColesterolHDL(){
        return this.colesterolHDL;
    }
    
    public void setColesterolLDL(int colesterolLDL){
        this.colesterolLDL = colesterolLDL;
    }
    public int getColesterolLDL(){
        return this.colesterolLDL;
    }

    public void setColesterolVLDL(int colesterolVLDL){
        this.colesterolVLDL = colesterolVLDL;
    }
    public int getColesterolVLDL(){
        return this.colesterolVLDL;
    }
 
    public void setGlicose(int glicose){
        this.glicose = glicose;
    }
    public int getGlicose(){
        return this.glicose;
    }


    public String medirTriglicerides(){
        if(this.triglicerides < 150)
            return "Nivel desejavel";
        else if(this.triglicerides < 200)
            return "Nivel limitrofe";
        else if(this.triglicerides < 500)
            return "Nivel alto";
        else
            return "Nivel muito alto";
    }
    
    public String medirColesterolTotal(){
        if(this.colesterolTotal < 200)
            return "Desejavel";
        else if(this.colesterolTotal < 240)
            return "Limitrofe";
        else
            return "Elevado";    
    }
    
    public String medirColesterolHDL(){
        if(this.colesterolHDL < 40)
            return "Baixo";
        else if(this.colesterolHDL <= 60)
            return "Normal";
        else
            return "Desejavel";    
    }
    
    public String medirColesterolLDL(){
        if(this.colesterolLDL < 100)
            return "Otimo";
        else if(this.colesterolLDL < 129)
            return "Desejavel";
        else if(this.colesterolLDL < 159)
            return "Limitrofe";
        else if(this.colesterolLDL < 189)
            return "Alto";
        else
            return "Muito alto";    
   }
    
    public String medirColesterolVLDL(){
        if(this.colesterolVLDL < 30)
            return "Nivel desejavel";
        else if(this.colesterolVLDL <= 40)
            return "Nivel limitrofe";
        else
            return "Nivel elevado";   
    }
    
    public String medirGlicose(){
        if(this.glicose < 60)
            return "Hipoglicemia";
        else if(this.glicose < 100)
            return "Desejavel";
        else if(this.glicose < 126)
            return "Glicemia de jejum inapropriada";
        else 
            return "Diabetes";
    
    }
}
