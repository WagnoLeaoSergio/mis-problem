

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class test_Exames
{
    private Exames exame;
    
    public test_Exames()
    {
    }

    @Before
    public void setUp()
    {
        exame = new Exames();
    }

    @After
    public void tearDown()
    {
    }
    
    
    @Test
    public void  medirTriglicerides_desejavel_test(){
        this.exame.setTriglicerides(149);
        assertEquals("Nivel desejavel", exame.medirTriglicerides());
    }
    @Test
    public void  medirTriglicerides_limitrofe_test(){
        this.exame.setTriglicerides(198);
        assertEquals("Nivel limitrofe", exame.medirTriglicerides());        
    }
    @Test
    public void  medirTriglicerides_alto_test(){
        this.exame.setTriglicerides(499);
        assertEquals("Nivel alto", exame.medirTriglicerides());        
    }
    @Test
    public void  medirTriglicerides_muitoAlto_test(){
        this.exame.setTriglicerides(500);
        assertEquals("Nivel muito alto", exame.medirTriglicerides());        
    }
    
    
    @Test
    public void medirColesterolTotal_desejavel_test(){
        this.exame.setColesterolTotal(199);
        assertEquals("Desejavel", exame.medirColesterolTotal());
    }
    @Test
    public void medirColesterolTotal_limitrofe_test(){
        this.exame.setColesterolTotal(238);
        assertEquals("Limitrofe", exame.medirColesterolTotal());
    }
    @Test
    public void medirColesterolTotal_elevado_test(){
        this.exame.setColesterolTotal(240);
        assertEquals("Elevado", exame.medirColesterolTotal());
    }

    
    @Test
    public void medirColesterolHDL_baixo_test(){
        this.exame.setColesterolHDL(39);
        assertEquals("Baixo", exame.medirColesterolHDL());
    }
    @Test
    public void medirColesterolHDL_normal_test(){
        this.exame.setColesterolHDL(40);
        assertEquals("Normal", exame.medirColesterolHDL());
    }
    @Test
    public void medirColesterolHDL_desejavel_test(){
        this.exame.setColesterolHDL(61);
        assertEquals("Desejavel", exame.medirColesterolHDL());
    }
 
    
    @Test
    public void medirColesterolLDL_otimo_test(){
        this.exame.setColesterolLDL(99);
        assertEquals("Otimo", exame.medirColesterolLDL());
    }
    @Test
    public void medirColesterolLDL_desejavel_test(){
        this.exame.setColesterolLDL(100);
        assertEquals("Desejavel", exame.medirColesterolLDL());
    }
    @Test
    public void medirColesterolLDL_limitrofe_test(){
        this.exame.setColesterolLDL(130);
        assertEquals("Limitrofe", exame.medirColesterolLDL());
    }
    @Test
    public void medirColesterolLDL_alto_test(){
        this.exame.setColesterolLDL(160);
        assertEquals("Alto", exame.medirColesterolLDL());
    }
    @Test
    public void medirColesterolLDL_muitoAlto_test(){
        this.exame.setColesterolLDL(190);
        assertEquals("Muito alto", exame.medirColesterolLDL());
    }
   
    
    @Test
    public void medirColestrolVLDL_NivelDesejavel_test(){
        this.exame.setColesterolVLDL(29);
        assertEquals("Nivel desejavel", exame.medirColesterolVLDL());
    }
    @Test
    public void medirColestrolVLDL_NivelLimitrofe_test(){
        this.exame.setColesterolVLDL(30);
        assertEquals("Nivel limitrofe", exame.medirColesterolVLDL());
    }
    @Test
    public void medirColestrolVLDL_NivelElevado_test(){
        this.exame.setColesterolVLDL(41);
        assertEquals("Nivel elevado", exame.medirColesterolVLDL());
    }
    
    
    @Test
    public void medirGlicose_hipoglicemia_test(){
        this.exame.setGlicose(59);
        assertEquals("Hipoglicemia", exame.medirGlicose());
    }
    @Test
    public void medirGlicose_desejavel_test(){
        this.exame.setGlicose(60);
        assertEquals("Desejavel", exame.medirGlicose());
    }
    @Test
    public void medirGlicose_GlicemiaDeJejumInapropriada_test(){
        this.exame.setGlicose(100);
        assertEquals("Glicemia de jejum inapropriada", exame.medirGlicose());
    }
    @Test
    public void medirGlicose_diabetes_test(){
        this.exame.setGlicose(126);
        assertEquals("Diabetes", exame.medirGlicose());
    }
    
}
